import sequelize from "./src/config/db.config.js";
import express from "express";
import userRouter from "./src/routes/user.routes.js"

const app=express();
app.use(express.json());
app.use('/api/users', userRouter);




sequelize
  .authenticate()
  .then(() => {
    console.log("Connection to the database has been established successfully.");
  })
  .catch((err) => {
    console.error("Unable to connect to the database:", err);
  });

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
