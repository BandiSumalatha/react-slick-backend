import { DataTypes } from "sequelize";
import sequelize from "../config/db.config.js";
// import UserCredentials from "./Credentials.model.js";

const User=sequelize.define('user',{
id:{
    type:DataTypes.INTEGER,
    primaryKey:true,
    autoIncrement:true
},
fname:{
   type:DataTypes.STRING,
   allowNull:false, 
},
lname:{
    type:DataTypes.STRING,
    allowNull:false
},
mmname:{
    type:DataTypes.STRING,
    allowNull:true
},
email:{
    type:DataTypes.STRING,
    allowNull:false
},
phonenumber:{
   type:DataTypes.STRING,
   allownull: false,
},
age:{
   type:DataTypes.INTEGER,
   allowNull:true 
},
gender:{
    type:DataTypes.STRING,
    allowNull:true
},
language:{
    type:DataTypes.ARRAY(DataTypes.STRING),
    allowNull:false
}

});


export default User;