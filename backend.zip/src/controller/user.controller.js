import User from "../models/User.model.js";
import UserCredentials from "../models/Credentials.model.js";
import bcrypt from "bcrypt"
const UserRegister = async (req, res) => {
    try {
        const userData = req.body;
        if (userData.password !== userData.confirmPassword) {
            return res.status(400).json({ message: 'password dont match' })
        }
        const hashedPassword = await bcrypt.hash(userData.password, 10)
        const newUser = await User.create(userData, { include: [UserCredentials] })
        await UserCredentials.create({
            password: hashedPassword,
            confirmPassword: hashedPassword,
            userId: newUser.id
        })
        return res.status(201).json({ message: 'User registered successfully', user: newUser })
    } catch (err) {
        return res.status(500).json({ mesage: 'Internal server error' })
    }
}

const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOnde({ where: { email } });

        if (!user) {
            return res.status(401).json({ message: 'user not found' });
        }
        const userCredential = await UserCredentials.findOnde({ where: { userId: user.id } });
        if (!userCredential || !bcrypt.compareSync(password, userCredential.password)) {
            return res.status(401).json({ message: 'invalid email and password' });
        }
        const token = jwt.sign({ userId: user.id }, 'your_secret_key', { expiresIn: '1h' });
        return res.status(200).json({ message: 'Login Successful', token })
    } catch (err) {
        console.log(err);
        return res.status(500).json({ message: 'Internal server error' })
    }
}

export { UserRegister, loginUser}