import express from 'express';
import { UserRegister,loginUser } from "../controller/user.controller.js";
const router = express.Router();
router.post('/register', UserRegister);
router.post('/loginuser', loginUser);
export default router;

